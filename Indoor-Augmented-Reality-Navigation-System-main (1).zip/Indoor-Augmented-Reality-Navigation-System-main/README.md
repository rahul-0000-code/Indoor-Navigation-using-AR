# Indoor-Augmented-Reality-Navigation-System
An Indoor Augmented Reality Navigation System using Unity

Result

![image](https://user-images.githubusercontent.com/108611184/178309600-a4790180-848b-46fd-8cd3-5d3e53b5d8b1.png)

Output of Indoor AR Navigation System of ACEM


![image](https://user-images.githubusercontent.com/108611184/178309680-af282e15-1629-4a55-9417-af28271d208f.png)

Switch View with Minimap


![image](https://user-images.githubusercontent.com/108611184/178310286-61c1b52e-74d0-4275-85a2-fc10d17600a1.png)

Minimap


https://user-images.githubusercontent.com/108611184/178787331-c974bedb-3e6f-4037-973e-30ee60f35823.mp4

Project by:

sudikshya Rajkarnikar

Subiddya Panthee (https://github.com/IcyflameIV)

Rabiya Begum

